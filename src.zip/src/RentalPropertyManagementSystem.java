import java.util.ArrayList;

import BackEnd.DatabaseController;
import BackEnd.EmailSystem;
import Employee.Manager;
import Employee.Property;
import gui.GUI;
import gui.WindowListener;

public class RentalPropertyManagementSystem{
  GUI gui;

  public static void main(String[] args){
    System.out.println("Running program...");

    RentalPropertyManagementSystem app = new RentalPropertyManagementSystem();
    app.createWindow();
 /*   DatabaseController data = new DatabaseController();
    data.dbConnect();
    ArrayList<Property> prop = data.fetchAllProperty();
    System.out.println(prop.size());
    Property save = new Property();
    save.setStatus("Active");
    save.setHouseType("apartment");
    save.setAddress("123 moussavi drive");
    save.setNumBathrooms(2);
    save.setNumBedrooms(4);
    save.setIfFurnished(0);
    save.setQuadrant("NE");
    save.setRentCost(1500);
    save.setPropertyFee(50);
    save.setFeePaid(1);
    save.setFeePeriod(3);
    save.setLandlordID("L0002");
    data.saveNewProperty(save);
    prop = data.fetchAllProperty();
    System.out.println(prop.get(2).getStatus());
    data.changePropertyState("P0003", "Suspended");
    prop = data.fetchAllProperty();
    System.out.println(prop.get(2).getStatus());
    
   // Manager man = (Manager)data.checkUserLogin("manager1", "password1", "manager");
   // System.out.println(man.getUsername());
    EmailSystem.sendEmail("ensf480landlord1@gmail.com", "ensf480renter1@gmail.com", "Testing ok", "Everthing is fine lol");
  */
    
    
  }

  private void createWindow(){
    gui = new GUI(1000, 800);
    WindowListener guiListener = new WindowListener();

    gui.addWindowListener(guiListener);

    gui.setVisible(true);
  }
}
